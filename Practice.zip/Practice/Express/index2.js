const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const mysql = require('mysql');

const app = express();

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: 'conatctformdb',
  password: ''
});

con.connect(function(error) {
  if (error) throw error;
  console.log('Database Connected');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'Prit9451',
  resave: false,
  saveUninitialized: true
}));


app.get('/', function(req, res) {
  res.sendFile(__dirname + '/login.html'); 
});

app.post('/login', function(req, res) {
  let user = req.body.username;
  let pass = req.body.password;

  if (user && pass) {
    let sql = 'SELECT * FROM user WHERE username = ? AND password = ?'; 
    con.query(sql, [user, pass], function(error, results) {
      if (error) throw error;
      if (results.length > 0) {
        req.session.loggedin = true;
        req.session.user = user;
        res.redirect('/home');
      } else {
        res.send('Invalid password or username. <a href="/">Try again</a>');
      }
    });
  } else {
    res.send("Please enter username and password. <a href="/">Go back</a>");
  }
});

app.get('/home', (req, res) => {
  if (req.session.loggedin) {
    res.sendFile(__dirname + '/ragister2.html'); 
  } else {
    res.send('Please log in to view this page. <a href="/">Login</a>');
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.redirect('/home'); 
    }
    res.redirect('/'); 
  });
});

app.post('/formsubmit', (req, res) => {
  const { name, surname, email, need, message } = req.body;
  const sql = 'INSERT INTO conatctform (name, surname, email, need, message) VALUES (?, ?, ?, ?, ?)';
  con.query(sql, [name, surname, email, need, message], function(error) {
    if (error) throw error;
    res.sendFile(__dirname + '/ragister2.html'); 
  });
});

app.listen(8082, function(err) {
  if (err) throw err;
  console.log("Server is created");
});
