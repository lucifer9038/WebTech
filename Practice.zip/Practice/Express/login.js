const express=require('express')
const app=express();
const bodyParser=require ('body-parser');
var session =require('session');

var mysql=require('mysql');
const session = require('express-session');
var con=mysql.createConnection({
  host: "localhost",
  user: "root",
  database:'conatctformdb',
  password: ''
})
con.connect(function(error){
    if(error) throw error;
    console.log('Database Connected')
    
})

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret:'Prit9451',
    resave:false,
    saveUninitialized:true
}))



app.get('/',function(req,res){
   res.sendFile(__dirname+'/login.html')
})

app.post('/login',(req,res)=>{
    let user=req.body.user;
    let pass=req.body.pass;
    if(user && pass)
    {
        let sql= 'select  * from login where  user=? AND pass=?';
        con.query(sql,[username,password],function(error,results,fields){
            if(error) throw error;
            if(results.length>0)
            {
                req.session.loggedin=true;
                req.session.username=user;
                res.redirect('/home');
            }
            else{
                res.send('Invalid password');
                res.closed();
            }
        })
    }
    else{
        res.send('Please Enter username and password');
    }

app.get('/home',(req,res)=>{
    if(req.session.loggedin){

    }
})
    const {username,password}=req.body;
    const sql='insert into user (username,password) values(?,?) ';
    con.query(sql,[username,password],
    function(error){
        if(error) throw error;
        res.send("Data Inerted")
    })
})

app.listen(8082,function(err){
    if (err) throw  err;
    console.log("Server is created")
})