function show() {
    var a = document.getElementById('1').style.display;
    if (a == 'none') {
        document.getElementById('1').style.display = 'block';
    } else {
        document.getElementById('1').style.display = 'none';
    }
}

function bg() {
    var paragraph = document.getElementById('1');
    if (paragraph.style.background === 'yellow') {
        paragraph.style.background = 'none';
    } else {
        paragraph.style.background = 'yellow';
    }
}
function color(){
    var paragraph = document.getElementById('1');
    if (paragraph.style.color == 'red') {
        paragraph.style.color = 'black';
    } else {
        paragraph.style.color = 'red';
    }
}
function border(){
    var paragraph = document.getElementById('1');
    if (paragraph.style.border == '2px solid black') {
        paragraph.style.border = 'none';
    } else {
        paragraph.style.border = '2px solid black';
    }
}
function bold(){
    var paragraph = document.getElementById('1').style.fontWeight;
    if (paragraph == 'bold') {
        document.getElementById('1').style.fontWeight = 'normal';
    } else {
        document.getElementById('1').style.fontWeight = 'bold';
    }
}
