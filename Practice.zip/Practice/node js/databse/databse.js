const mysql = require('mysql');

// Create a connection to the database
const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "" // Your MySQL root password
});

// Connect to MySQL
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to MySQL!");

  // Create a new database
  con.query("CREATE DATABASE IF NOT EXISTS testdb", function (err, result) {
    if (err) throw err;
    console.log("Database created");

    // Use the new database
    con.query("USE testdb", function (err, result) {
      if (err) throw err;

      // Create a new table
      const createTableQuery = `CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL
      )`;
      con.query(createTableQuery, function (err, result) {
        if (err) throw err;
        console.log("Table created");

        // CRUD Operations

        // Create (Insert)
        const insertQuery = "INSERT INTO users (name, email) VALUES ('John Doe', 'john@example.com')";
        con.query(insertQuery, function (err, result) {
          if (err) throw err;
          console.log("1 record inserted");

          // Read (Select)
          con.query("SELECT * FROM users", function (err, result) {
            if (err) throw err;
            console.log("Users:", result);

            // Update
            const updateQuery = "UPDATE users SET email = 'john.doe@example.com' WHERE name = 'John Doe'";
            con.query(updateQuery, function (err, result) {
              if (err) throw err;
              console.log("1 record updated");

              // Delete
              const deleteQuery = "DELETE FROM users WHERE name = 'John Doe'";
              con.query(deleteQuery, function (err, result) {
                if (err) throw err;
                console.log("1 record deleted");

                // Close the connection
                con.end(function(err) {
                  if (err) throw err;
                  console.log("Connection closed");
                });
              });
            });
          });
        });
      });
    });
  });
});