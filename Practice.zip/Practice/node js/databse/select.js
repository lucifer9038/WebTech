var mysql=require('mysql')
var con=mysql.createConnection({
  host: "localhost",
  user: "root",
  database:'Pritesh',
  password: ''
})
con.connect(function(error){
    if(error) throw error;
    console.log('Database Connected')
    con.query("SELECT * FROM customers", function (err, result) {
        if (err) throw err;
        console.log(result);
      });
})