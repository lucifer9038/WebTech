var events=require('events');
var EventEmitter=new events.EventEmitter();
var mysql=require('my')

var handler=function(){
    console.log("Bulb is On");
}

var handler1=function(){
    console.log("Bulb is off");
}
EventEmitter.on('on',handler);
EventEmitter.on('off',handler1);
EventEmitter.on('ON!',handler);

EventEmitter.emit('on');
EventEmitter.emit('off');
EventEmitter.emit('ON!');