var mysql=require('mysql')
var con=mysql.createConnection({
  host: "localhost",
  user: "root",
  password: ''
})
con.connect(function(error){
    if(error) throw error;
    console.log('Database Connected')
    con.query("CREATE DATABASE Pritesh", function (err, result) {
        if (err) throw err;
        console.log("Database created");
      });
})