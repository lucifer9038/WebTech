var mysql=require('mysql')
var con=mysql.createConnection({
  host: "localhost",
  user: "root",
  database:'Pritesh',
  password: ''
})
con.connect(function(error){
    if(error) throw error;
    console.log('Database Connected')
    var sql = "CREATE TABLE customers (name VARCHAR(255), address VARCHAR(255))";
    con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });
})