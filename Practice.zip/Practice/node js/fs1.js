var http=require('http');
var fs1=require('fs');

fs1.writeFile("demo.txt",'This Demo  is created by node js',function(error){
    if(error) throw error;
    console.log('File is creatd')
});

fs1.readFile("demo.txt",'utf-8',function(error ,data){
    if(error) throw error;
    console.log(data);
});