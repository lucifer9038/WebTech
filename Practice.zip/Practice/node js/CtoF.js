exports.ctof=function(c){
            f=c*(9/5) + 32
            return f;
        

}