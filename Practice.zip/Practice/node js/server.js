var http=require('http');
var add=require('./m1');
var ctof=require('./CtoF')
http.createServer(function(req,res){
    res.writeHead(200,{'content-Type':'text/plain'});
    res.write("This is my first program of node js");
    res.write("\n"+add.add(5,10))
    res.write("\n"+ctof.ctof(30))

    res.end();
}).listen(8082);

console.log("Server is created")