var http = require('http');
var fs1 = require('fs');

let currentFileName = "demo.txt"; // Variable to keep track of the current file name

process.stdout.write("Enter your choice:\n 1. Create file \n 2. Read file \n 3. Append data \n 4. Rename file \n 5. Delete file\n ----> ")

process.stdin.on('data', function(data) {
    data = data.toString().trim(); // Convert Buffer to string and trim whitespace

    if (data == 1) {
        fs1.writeFile(currentFileName, 'This Demo is created by node js', function(error) {
            if (error) throw error;
            console.log('File is created');
        });
    } else if (data == 2) {
        fs1.readFile(currentFileName, 'utf-8', function(error, fileData) {
            if (error) {
                console.error("Error reading file:", error);
            } else {
                console.log(fileData);
            }
        });
    } else if (data == 3) {
        fs1.appendFile(currentFileName, '\n Hey This is new Text', function(error) {
            if (error) throw error;
            console.log('Data has been appended to the file');
        });
    } else if (data == 4) {
        process.stdout.write("Enter the old file name:\n");
        process.stdin.once('data', function(oldFileName) {
            oldFileName = oldFileName.toString().trim(); // Get the old file name
            fs1.access(oldFileName, fs1.constants.F_OK, function(err) {
                if (err) {
                    console.error("Old file does not exist.");
                } else {
                    process.stdout.write("Enter the new file name:\n");
                    process.stdin.once('data', function(newFileName) {
                        newFileName = newFileName.toString().trim(); // Get the new file name
                        fs1.rename(oldFileName, newFileName, function(error) {
                            if (error) throw error;
                            console.log('File renamed from ' + oldFileName + ' to ' + newFileName);
                        });
                    });
                }
            });
        });
    } else if (data == 5) {
        process.stdout.write("Enter the file name to delete:\n");
        process.stdin.once('data', function(fileNameToDelete) {
            fileNameToDelete = fileNameToDelete.toString().trim(); // Get the file name to delete
            fs1.access(fileNameToDelete, fs1.constants.F_OK, function(err) {
                if (err) {
                    console.error("File does not exist, cannot delete.");
                } else {
                    fs1.unlink(fileNameToDelete, function(error) {
                        if (error) throw error;
                        console.log("File has been deleted");
                    });
                }
            });
        });
    } else {
        console.log("Invalid choice. Please select a valid option.");
    }
});