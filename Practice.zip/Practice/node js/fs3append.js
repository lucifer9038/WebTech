//give me code on Opening a file in node js?

// var http=require('http');
// var fs1=require('fs');

// fs1.appendFile('index.html','<h5>Hey i am Pritesh</h5>',function(error){
//     if(error) throw error;
//     console.log("data is inserted");
// })
var http = require('http');
var fs = require('fs');

fs.readFile('index.html', function(err, data) {
    if (err) {
        console.error(err);
        return;
    }
    console.log(data.toString());
});