var http=require('http');
var fs1=require('fs');


fs1.writeFile('index.html','<h1>Hello World</h1>',function(error){
    if(error) throw error;
    console.log("File is created");
})
fs1.appendFile('index.html','<h5>Hey i am Pritesh</h5>',function(error){
    if(error) throw error;
    console.log("data is inserted");
})

http.createServer(function(req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    fs1.readFile("index.html", function(error, data) {
        if (error) throw error;
        res.write(data);
        res.end();
    });
}).listen(8082);