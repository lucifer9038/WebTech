import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>Contact Page</h1>
      <p>Reach us at contact@example.com.</p>
    </div>
  );
};

export default Contact;
